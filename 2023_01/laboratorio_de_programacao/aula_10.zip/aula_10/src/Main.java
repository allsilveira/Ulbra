public class Main {
    public static void main(String[] args) throws Exception {
        Student student01 = new Student("Lucas", 159, "ADS");
        Student student02 = new Student("Lucas", 159);

        Book book01 = new Book("HP Vol.01", "JK", 78.00);
        Book book02 = new Book("HP Vol.01", "JK");

        Dog dog01 = new Dog("Bethoven", "Pastor alemao", 16);
        Dog dog02 = new Dog("Cesa", "Viralata");
    }

}