public class Student {
    private String Name;
    private int Age;
    private int Points;

    public Student() {
    }

    public void setName(String name) {
        this.Name = name;
    }

    public void setAge(int age) {
        this.Age = age;
    }

    public void setPoints(int points) {
        this.Points = points;
    }

    public String getName() {
        return this.Name;
    }

    public int getAge() {
        return this.Age;
    }

    public int getPoints() {
        return this.Points;
    }
}
