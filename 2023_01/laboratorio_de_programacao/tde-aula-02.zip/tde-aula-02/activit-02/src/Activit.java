public class Activit {
    public static void main(String[] args) {
        printNumbersInRange(10, 25);
    }
    public static void printNumbersInRange(int init, int finish) {
        for (int i = init; i <= finish; i++) {
            System.out.println(i);
        }
    }
}

