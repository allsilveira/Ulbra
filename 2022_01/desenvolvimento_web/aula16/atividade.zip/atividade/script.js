//atividade 1

/*var num = parseFloat(prompt('Digite um número:'))

if (num < 10){
    alert('Não é maior que 10')
}else if(num > 10){
    alert('É maior que 10')
}else if(num == 10){
    alert('É igual a 10')
}else {
    alert('Não é um número')
}
*/

//atividade 2
/*
var num1 = parseFloat(prompt('Digite um número:'));
var num2 = parseFloat(prompt('Digite outro número:'));
soma= num1+num2;

alert(`A soma de ${num1} e ${num2} é ${soma}.`)
*/

//atividade 3

/*
var num1 = parseFloat(prompt('Digite um número:'));
var num2 = parseFloat(prompt('Digite outro número:'));
var op = prompt("Qual operador deseja utilizar? ( +, -, * ou /)");

switch (op){
    case '*':
        alert(num1*num2);
        break;

    case '/':
        alert(num1/num2);
        break;
    
    case '-':
        alert(num1-num2);
        break;

    default:
        alert(num1+num2);
        
}
*/

//atividade 4

/*
var nome = prompt('Digite uma palavra:');
var n = parseFloat(prompt('Quantas vezes deseja repeti-la?'))

for (i=0; i <= n; i++){
    alert(nome);
}
*/

//atividade 5

/*
var info = [];

info[0]= prompt('Qual seu nome?');
info[1]= prompt('Qual seu endereço?');
info[2]= prompt('Qual seu e-mail?');

alert(info)
*/