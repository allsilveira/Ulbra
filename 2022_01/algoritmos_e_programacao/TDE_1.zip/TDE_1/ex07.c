#include <stdio.h>

/*Faça um programa que escreva os números de 1 a 20, em ordem decrescente*/

int main(){
    int i;

   for(i=20;i>0;i--){
       printf("Número:%d\n",i);
   }
}