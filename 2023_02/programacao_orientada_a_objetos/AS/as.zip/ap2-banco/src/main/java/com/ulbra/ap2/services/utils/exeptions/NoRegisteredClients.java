package com.ulbra.ap2.services.utils.exeptions;

public class NoRegisteredClients extends Exception {
    public NoRegisteredClients(String message) {
        super(message);
    }
}
