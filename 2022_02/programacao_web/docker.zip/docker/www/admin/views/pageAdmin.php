<main class="container-fluid d-md-flex">
  <div class="col-md-4 bg-dark text-white">
    <h1>
      Menu
    </h1>
    <ul>
      <li>
        <a class="text-white" href="">Home</a>
      </li>
    </ul>
  </div>
  <div class="col-md-8">

  </div>
</main>