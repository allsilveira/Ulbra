<!-- </section>

</main>
<footer class="p-2 text-center container-fluid bg-dark ">
    <p class="py-0 text-white">Copyright©<a href="https://github.com/allsilveira" class="text-white">Alessandra Silveira</a></p>
    <a href="<?= base_url('/') ?>">Site</a>
</footer>
</body>

</html> -->