<main class="container-fluid my-5 p-4 py-0">
    <header>
        <h1>Contato</h1>
    </header>
    <section class="card py-5 pb-3">
        <ul>
            <li class="d-flex list-item align-content-center">
                <h2 class="fs-5 pe-2">Endereço: </h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li class="d-flex list-item align-content-center">
                <h2 class="fs-5 pe-2">Telefone: </h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
        </ul>
    </section>
</main>