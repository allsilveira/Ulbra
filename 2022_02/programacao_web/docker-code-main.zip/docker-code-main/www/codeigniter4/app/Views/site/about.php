<main class="container-fluid my-5 p-4 py-0">
    <header>
        <h1>Sobre</h1>
    </header>
    <section>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere eligendi nisi voluptatum minima! Voluptatum iusto voluptates pariatur eius ducimus quod reiciendis nulla optio beatae cupiditate. Perferendis a cum eveniet fuga!
        </p>
        <!-- <img class="img-fluid" src="https://source.unsplash.com/random" alt="imagem aleatoria"> -->
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic repellendus maxime saepe a quo molestiae placeat, mollitia fugit temporibus perspiciatis, accusantium ad commodi laudantium explicabo. Aut iste voluptate asperiores amet?
        </p>
    </section>
</main>