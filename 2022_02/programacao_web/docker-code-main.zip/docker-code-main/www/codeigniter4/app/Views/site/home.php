<main class="container-fluid my-5 p-4 py-0">
    <header>
        <h1>Home</h1>
    </header>
    <section>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint quisquam, dolorem ad vero quasi dignissimos? Reprehenderit commodi accusamus dicta maiores, voluptate possimus ipsa vitae, nemo sunt quo ratione excepturi asperiores!
        </p>
        <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos et numquam accusamus consectetur consequuntur totam, neque aperiam vero aliquam delectus nemo maiores soluta possimus facilis inventore voluptatem fugit hic voluptatum?
        </p>
    </section>
</main>