<main class="container-fluid my-5 p-4 py-0">
    <section class="my-4 mx-3">
        <h1>Produtos&Serviços</h1>
    </section>
    <section class="d-md-flex justify-content-between">
        <div class="col-md-6">
            <h3 class="card-header">Produto xx</h3>
            <div class="card-body bg-primary" style="height: 150px;">

            </div>
        </div>
        <div class="col-md-5">
            <h3 class="card-header">Produto yy</h3>
            <div class="card-body bg-secondary" style="height: 150px;">

            </div>
        </div>
    </section>
    <section class="d-md-flex justify-content-between mt-3">
        <div class="col-md-6">
            <h3 class="card-header">Serviço xx</h3>
            <div class="card-body bg-success p-2" style="height: 150px;">
                <p class="text-white">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis necessitatibus autem possimus eligendi nihil impedit cupiditate.
                </p>
            </div>
        </div>
        <div class="col-md-5">
            <h3 class="card-header">Serviço yy</h3>
            <div class="card-body bg-danger p-2" style="height: 150px;">
                <p class="text-white">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugiat excepturi porro consequatur enim illo vel exercitationem atque quisquam beatae eligendi rem molestias esse accusamus, architecto ipsum aspernatur quaerat tempora quo?
                </p>
            </div>
        </div>
    </section>
</main>